$(document).ready(function (){

    $('.small a').mouseover(function(e){ //обхект для блокировки стандартного поведения ссылки
        e.preventDefault();//блокировка стандартного поведения

        if ($('.big img').attr('src') !=$(this).attr('href')){
            
            // e.preventDefault();//блокировка стандартного поведения

            $('.big img').hide().attr('src', $(this).attr('href')).fadeIn(1000).css({
                width: '100%',
                height: '100%',
            });
        }
    });

    //выделение выбранной картинки
    $('.small a img').mouseover(function () {
        $(this).fadeTo(600, 0.6).css(
            {
                border: '1px dotted red',
                color: "red", 
            }
            );
    });
    $(document).mouseover(function(){
        $('.small a img').fadeTo(0, 1).css(
                {
                    border: 'none', 
                    color: "red" ,
                });
    });


    $(document).mouseover(function () {

        $('.small a img').fadeTo(0, 1).css(

            {

                border: 'none',

            });

    });

});


// ----------------------------------------------

 //открыть по кнопке
 $('.sviaz').click(function (){
    $('.overlay').fadeIn();
});

  //закрытие по клику вне окна
  $(document).mouseup(function(){
    $('.overlay').fadeOut();
});

// ----------------------------------------------

 //открыть по кнопке
 $('#inin').click(function (){
    $('.overlay2').fadeIn();
});

  //закрытие по клику вне окна
  $(document).mouseup(function(){
    $('.overlay2').fadeOut();
});

// -----------Авыторизация---------------------------------

//открыть по таймеру
$(window).on('load', function (){
    setTimeout(function(){
        if ($('.overlay_new').hasClass('disabled')){
            return false;
        } else {
            $(".overlay_new").fadeIn();
        }
    }, 1);
})

$('.but1').click(function(e){
    e.preventDefault();

    if($('.login input').val() == 'test' && $('.pas input').val() == 'test'){
        alert('Авторризация пройдена успешно!');
        $(".overlay_new").fadeOut();
        
        if($('.log input').val() != ''){
            $('.log input').val ('')
        }

        if($('.pas input').val() != ''){
            $('.pas input').val ('')
        }
    }
    else {
        alert('Вы указали неверные данные');
        if ($('.log input').val() != ''){
            $('.log input').val ('')
            
        }

        if($('.pas input').val() !='') {
            $('.pas input').val ('')
        }
    }
})
// ___________________________________________________________________

$(function(){
    setInterval(function() {
        $('.banner').animate({
            'font-size': '14pt'
        }, 1000 ).animate({
            'font-size': '16pt',
        },1000);
    }, 1000); // общее время выполнения одной итерации анимации (1000 + 1000) в миллисекундах
});

$(function(){
    setInterval(function() {
        $('.banban').animate({
            'width': '300px',
            'height': '150px'

        }, 1000 ).animate({
            'width': '350px',
            'height': '200px'
        },1000);
    }, 1000); // общее время выполнения одной итерации анимации (1000 + 1000) в миллисекундах
});


// _______________________________________________________________

//  открыть по кнопке
 $('#cont').click(function (){
    $('.ccc').fadeIn();
});

  //закрытие по клику вне окна
//   $('#submitBtn').click(function(){
//     $('.ccc').fadeOut();
// });

$(function(){
    $('.form').submit(function (e){
      e.preventDefault();
      if($('#fname').val() == '' || $('#lName').val() == '' || $('#email').val() == '' || $('.textarea').val() == ''){
        alert('вы не заполнили форму')
        $('#email').mask('addres@gmail.com')
    }
        else{
            alert('форма отправлена')
            // $('#submitBtn').click(function(){
            //     $('.ccc').fadeOut();
            // });
        }

    })
})





